swapoff /dev/zram0
aumix -v99



